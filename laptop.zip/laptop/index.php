<?php
	
 echo "<meta http-equiv='refresh' content='1;URL=frontend/index.html'>"


?>